(function () {
  'use strict';

  const globalToggle = document.getElementById('globalToggle');
  const statusPill   = document.getElementById('statusPill');
  const statusDot    = document.getElementById('statusDot');
  const statusText   = document.getElementById('statusText');
  const rulesList    = document.getElementById('rulesList');
  const newTarget    = document.getElementById('newTarget');
  const newBg        = document.getElementById('newBg');
  const addBtn       = document.getElementById('addBtn');
  const applyBtn     = document.getElementById('applyBtn');

  let rules = [];
  let globalEnabled = true;

  chrome.storage.local.get(['rules', 'globalEnabled'], (r) => {
    rules = r.rules || [];
    globalEnabled = r.globalEnabled !== false;
    globalToggle.checked = globalEnabled;
    syncStatusUI(globalEnabled);
    renderRules();
  });

  globalToggle.addEventListener('change', () => {
    globalEnabled = globalToggle.checked;
    chrome.runtime.sendMessage({ type: 'SET_GLOBAL', value: globalEnabled });
    syncStatusUI(globalEnabled);
  });

  function syncStatusUI(on) {
    if (on) {
      statusPill.className = 'status-pill';
      statusText.textContent = 'AKTIF';
    } else {
      statusPill.className = 'status-pill off';
      statusText.textContent = 'NONAKTIF';
    }
  }

  function renderRules() {
    rulesList.innerHTML = '';
    if (!rules.length) {
      rulesList.innerHTML = '<div class="empty-state">Belum ada rule — tambahkan di bawah</div>';
      return;
    }
    rules.forEach((rule, idx) => {
      const row = document.createElement('div');
      row.className = 'rule-row' + (rule.enabled ? '' : ' disabled');

      row.innerHTML = `
        <input class="inp" type="text" value="${esc(rule.target)}" placeholder="URL target" data-field="target" data-idx="${idx}" />
        <input class="inp" type="text" value="${esc(rule.bgUrl)}" placeholder="URL background" data-field="bgUrl" data-idx="${idx}" />
        <div class="rule-actions">
          <button class="btn-icon ${rule.enabled ? 'on' : ''}" data-action="toggle" data-idx="${idx}" title="${rule.enabled ? 'Nonaktifkan' : 'Aktifkan'}">
            ${rule.enabled
              ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
              : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>`
            }
          </button>
          <button class="btn-icon del" data-action="delete" data-idx="${idx}" title="Hapus Rule">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </button>
        </div>
      `;
      rulesList.appendChild(row);
    });

    rulesList.querySelectorAll('.inp[data-field]').forEach(inp => {
      inp.addEventListener('change', () => {
        const i = +inp.dataset.idx;
        rules[i][inp.dataset.field] = inp.value.trim();
        saveRules();
        inp.classList.remove('error');
      });
      inp.addEventListener('input', () => inp.classList.remove('error'));
    });

    rulesList.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = +btn.dataset.idx;
        if (btn.dataset.action === 'toggle') {
          rules[i].enabled = !rules[i].enabled;
          saveRules();
          renderRules();
        } else if (btn.dataset.action === 'delete') {
          rules.splice(i, 1);
          saveRules();
          renderRules();
        }
      });
    });
  }

  function addRule() {
    const target = newTarget.value.trim();
    const bgUrl  = newBg.value.trim();
    let err = false;
    if (!target) { newTarget.classList.add('error'); shake(newTarget); err = true; }
    if (!bgUrl)  { newBg.classList.add('error');     shake(newBg);     err = true; }
    if (err) return;

    const dup = rules.some(r =>
      r.target.toLowerCase() === target.toLowerCase() &&
      r.bgUrl.toLowerCase() === bgUrl.toLowerCase()
    );
    if (dup) { shake(newTarget); shake(newBg); return; }

    rules.push({ id: Date.now() + Math.random(), target, bgUrl, enabled: true });
    saveRules();
    renderRules();
    newTarget.value = '';
    newBg.value = '';
    newTarget.focus();
  }

  addBtn.addEventListener('click', addRule);
  newTarget.addEventListener('keydown', e => { if (e.key === 'Enter') newBg.focus(); });
  newBg.addEventListener('keydown', e => { if (e.key === 'Enter') addRule(); });

  function saveRules() {
    chrome.runtime.sendMessage({ type: 'SAVE_RULES', rules });
  }

  applyBtn.addEventListener('click', () => {
    applyBtn.disabled = true;
    applyBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg> MENERAPKAN...`;

    chrome.runtime.sendMessage({ type: 'APPLY_NOW' }, (resp) => {
      applyBtn.disabled = false;
      if (resp && resp.ok) {
        applyBtn.className = 'btn-apply ok';
        applyBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg> BERHASIL DITERAPKAN!`;
      } else {
        applyBtn.className = 'btn-apply fail';
        const msg = (resp && resp.msg === 'no_match') ? 'TIDAK ADA RULE YANG COCOK' : 'GAGAL — RELOAD HALAMAN';
        applyBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg> ${msg}`;
      }
      setTimeout(() => {
        applyBtn.className = 'btn-apply';
        applyBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M5 3l14 9-14 9V3z" fill="currentColor"/></svg> TERAPKAN DI TAB INI SEKARANG`;
      }, 2500);
    });
  });

  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function shake(el) {
    const a = ['-5px','5px','-3px','0'];
    let i = 0;
    const t = setInterval(() => {
      el.style.transform = `translateX(${a[i++]})`;
      if (i >= a.length) { clearInterval(t); el.style.transform = ''; }
    }, 60);
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes.rules) { rules = changes.rules.newValue || []; renderRules(); }
    if (changes.globalEnabled) { globalEnabled = changes.globalEnabled.newValue; syncStatusUI(globalEnabled); globalToggle.checked = globalEnabled; }
  });

})();
