(function () {
  'use strict';

  function matchedRules(rules) {
    const url = window.location.href.toLowerCase();
    return (rules || []).filter(r => r.enabled && r.target && r.bgUrl && url.includes(r.target.toLowerCase()));
  }

  function applyBackground(rule) {
    const isVideo = /\.(mp4|webm|ogg|mov|avi|mkv)(\?|$)/i.test(rule.bgUrl);
    const styleId = `__kks_style_${rule.id}`;
    let styleEl = document.getElementById(styleId);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      (document.head || document.documentElement).appendChild(styleEl);
    }

    if (isVideo) {
      const vidId = `__kks_vid_${rule.id}`;
      let vid = document.getElementById(vidId);
      if (!vid) {
        vid = document.createElement('video');
        vid.id = vidId;
        vid.autoplay = true;
        vid.loop = true;
        vid.muted = true;
        vid.playsInline = true;
        vid.setAttribute('playsinline', '');
        vid.src = rule.bgUrl;
        applyVideoStyle(vid);
        document.body.insertBefore(vid, document.body.firstChild);
        window.addEventListener('resize', () => applyVideoStyle(vid));
        vid.addEventListener('loadedmetadata', () => tryUpgradeVideo(vid, rule), { once: false });
      }
      vid.play().catch(() => {});
      styleEl.textContent = 'body,html{background:transparent!important;}';
    } else {
      styleEl.textContent = `
        body,html{
          background-image:url("${rule.bgUrl}")!important;
          background-size:cover!important;
          background-position:center center!important;
          background-repeat:no-repeat!important;
          background-attachment:fixed!important;
          image-rendering:-webkit-optimize-contrast!important;
        }
      `;
    }
  }

  function applyVideoStyle(vid) {
    const vw = window.innerWidth, vh = window.innerHeight;
    const ratio = 16 / 9;
    let w, h, x, y;
    if (vw / vh > ratio) {
      w = vw; h = vw / ratio; x = 0; y = (vh - h) / 2;
    } else {
      h = vh; w = vh * ratio; x = (vw - w) / 2; y = 0;
    }
    vid.style.cssText = `
      position:fixed!important;
      top:${y}px!important;left:${x}px!important;
      width:${w}px!important;height:${h}px!important;
      object-fit:fill!important;
      z-index:-9999!important;
      pointer-events:none!important;
      image-rendering:-webkit-optimize-contrast!important;
    `;
  }

  function tryUpgradeVideo(vid, rule) {
    const w = vid.videoWidth, h = vid.videoHeight;
    if (!w || (w >= 7680 && h >= 4320)) return;
    const patterns = [
      [/\b(144|240|360|480|576|720|1080|1440|2160)p\b/gi, '4320p'],
      [/_(144|240|360|480|576|720|1080)_/g, '_7680_'],
      [/-(144|240|360|480|576|720|1080)-/g, '-7680-'],
      [/quality=(low|medium|sd|hd|auto)/gi, 'quality=highest'],
      [/[?&]res=\d+/gi, '?res=7680'],
    ];
    let upgraded = rule.bgUrl;
    for (const [re, rep] of patterns) {
      const t = upgraded.replace(re, rep);
      if (t !== upgraded) { upgraded = t; break; }
    }
    if (upgraded === rule.bgUrl) return;
    const probe = document.createElement('video');
    probe.style.cssText = 'display:none;position:fixed;visibility:hidden;';
    probe.preload = 'metadata';
    probe.src = upgraded;
    document.body.appendChild(probe);
    probe.addEventListener('loadedmetadata', () => {
      if (probe.videoWidth > w) { vid.src = upgraded; vid.load(); vid.play().catch(() => {}); }
      probe.remove();
    }, { once: true });
    probe.addEventListener('error', () => probe.remove(), { once: true });
    setTimeout(() => probe.remove(), 5000);
  }

  function run() {
    chrome.storage.local.get(['rules', 'globalEnabled'], (r) => {
      if (r.globalEnabled === false) return;
      matchedRules(r.rules).forEach(applyBackground);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(run, 300);
    }
  }).observe(document, { subtree: true, childList: true });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.rules || changes.globalEnabled) {
      document.querySelectorAll('[id^="__kks_style_"],[id^="__kks_vid_"]').forEach(el => el.remove());
      run();
    }
  });
})();
