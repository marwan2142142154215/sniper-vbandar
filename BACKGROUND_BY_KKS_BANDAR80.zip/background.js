chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['rules'], (r) => {
    if (!r.rules) {
      chrome.storage.local.set({
        rules: [{
          id: Date.now(),
          target: 'bandar80.idrbo2.com/player-name.html',
          bgUrl: '',
          enabled: true
        }],
        globalEnabled: true
      });
    }
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;
  if (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) return;

  chrome.storage.local.get(['rules', 'globalEnabled'], (r) => {
    if (!r.globalEnabled) return;
    const matched = (r.rules || []).filter(rule =>
      rule.enabled && rule.target && rule.bgUrl &&
      tab.url.toLowerCase().includes(rule.target.toLowerCase())
    );
    if (!matched.length) return;
    chrome.scripting.executeScript({ target: { tabId }, func: applyRules, args: [matched] }).catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_RULES') {
    chrome.storage.local.get(['rules', 'globalEnabled'], (r) => {
      sendResponse({ rules: r.rules || [], globalEnabled: r.globalEnabled !== false });
    });
    return true;
  }
  if (msg.type === 'SAVE_RULES') {
    chrome.storage.local.set({ rules: msg.rules });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'SET_GLOBAL') {
    chrome.storage.local.set({ globalEnabled: msg.value });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'APPLY_NOW') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) { sendResponse({ ok: false }); return; }
      chrome.storage.local.get(['rules', 'globalEnabled'], (r) => {
        if (!r.globalEnabled) { sendResponse({ ok: false }); return; }
        const matched = (r.rules || []).filter(rule =>
          rule.enabled && rule.target && rule.bgUrl &&
          tabs[0].url.toLowerCase().includes(rule.target.toLowerCase())
        );
        if (!matched.length) { sendResponse({ ok: false, msg: 'no_match' }); return; }
        chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, func: applyRules, args: [matched] })
          .then(() => sendResponse({ ok: true }))
          .catch(e => sendResponse({ ok: false, msg: e.message }));
      });
    });
    return true;
  }
});

function applyRules(rules) {
  const RATIO_W = 16, RATIO_H = 9;

  function force16x9(el) {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const screenRatio = vw / vh;
    const targetRatio = RATIO_W / RATIO_H;
    let w, h, x, y;
    if (screenRatio > targetRatio) {
      w = vw; h = vw / targetRatio; x = 0; y = (vh - h) / 2;
    } else {
      h = vh; w = vh * targetRatio; x = (vw - w) / 2; y = 0;
    }
    el.style.cssText = `
      position: fixed !important;
      top: ${y}px !important;
      left: ${x}px !important;
      width: ${w}px !important;
      height: ${h}px !important;
      min-width: ${w}px !important;
      min-height: ${h}px !important;
      object-fit: fill !important;
      z-index: -9999 !important;
      pointer-events: none !important;
      image-rendering: -webkit-optimize-contrast !important;
      image-rendering: high-quality !important;
    `;
  }

  function tryUpgradeUrl(url) {
    const map = [
      [/\b(144|240|360|480|576|720|1080|1440|2160)p\b/gi, '4320p'],
      [/_(144|240|360|480|576|720|1080|1440|2160)_/g, '_7680_'],
      [/-(144|240|360|480|576|720|1080|1440|2160)-/g, '-7680-'],
      [/\/(144|240|360|480|576|720|1080|1440|2160)\//g, '/7680/'],
      [/[?&]res=\d+/gi, '?res=7680'],
      [/quality=(low|medium|sd|hd|auto)/gi, 'quality=highest'],
      [/bitrate=\d+/gi, 'bitrate=99999999'],
      [/size=(small|medium|large)/gi, 'size=original'],
    ];
    for (const [re, rep] of map) {
      const r = url.replace(re, rep);
      if (r !== url) return r;
    }
    return null;
  }

  rules.forEach(rule => {
    if (!rule.bgUrl) return;
    const isVideo = /\.(mp4|webm|ogg|mov|avi|mkv)(\?|$)/i.test(rule.bgUrl);
    const styleId = `__kks_style_${rule.id}`;
    let styleEl = document.getElementById(styleId);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = styleId;
      document.head.appendChild(styleEl);
    }

    if (isVideo) {
      const vidId = `__kks_vid_${rule.id}`;
      let vid = document.getElementById(vidId);
      if (!vid) {
        vid = document.createElement('video');
        vid.id = vidId;
        vid.autoplay = true;
        vid.loop = true;
        vid.muted = true;
        vid.playsInline = true;
        vid.setAttribute('playsinline', '');
        vid.src = rule.bgUrl;
        document.body.insertBefore(vid, document.body.firstChild);
      } else if (vid.src !== rule.bgUrl) {
        vid.src = rule.bgUrl;
      }

      force16x9(vid);
      vid.play().catch(() => {});

      window.addEventListener('resize', () => force16x9(vid));

      vid.addEventListener('loadedmetadata', () => {
        const w = vid.videoWidth, h = vid.videoHeight;
        if (w > 0 && (w < 7680 || h < 4320)) {
          const upgraded = tryUpgradeUrl(rule.bgUrl);
          if (upgraded) {
            const probe = document.createElement('video');
            probe.style.cssText = 'display:none;position:fixed;visibility:hidden;';
            probe.preload = 'metadata';
            probe.src = upgraded;
            document.body.appendChild(probe);
            probe.addEventListener('loadedmetadata', () => {
              if (probe.videoWidth > w) { vid.src = upgraded; vid.load(); vid.play().catch(() => {}); }
              probe.remove();
            }, { once: true });
            probe.addEventListener('error', () => probe.remove(), { once: true });
            setTimeout(() => probe.remove(), 5000);
          }
        }
        force16x9(vid);
      }, { once: false });

      styleEl.textContent = 'body,html{background:transparent!important;}';

    } else {
      styleEl.textContent = `
        body,html{
          background-image:url("${rule.bgUrl}")!important;
          background-size:cover!important;
          background-position:center center!important;
          background-repeat:no-repeat!important;
          background-attachment:fixed!important;
          image-rendering:-webkit-optimize-contrast!important;
          image-rendering:high-quality!important;
        }
        body::before{
          content:""!important;
          position:fixed!important;
          top:0!important;left:0!important;
          width:100vw!important;height:100vh!important;
          background-image:url("${rule.bgUrl}")!important;
          background-size:cover!important;
          background-position:center center!important;
          z-index:-9999!important;
          aspect-ratio:16/9!important;
        }
      `;
    }
  });
}
